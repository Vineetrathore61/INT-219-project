
const express = require("express");
const path = require("path");

const app = express();

const loginData = require("../project of front end web development/routes/routes");
const routeRouter = require("../project of front end web development/routes/app");
// const bookingData = require("../routes/booking")

app.use(loginData);
app.use(routeRouter);
// app.use(bookingData);

app.listen(8080, ()=>{
    console.log("Server Started in 8080");
})